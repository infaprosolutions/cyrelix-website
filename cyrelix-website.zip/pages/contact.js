export default function Contact() {
  return (
    <main style={{ padding: "50px" }}>
      <h1>Contact Us</h1>
      <p>Email: support@infaprosolutions.com</p>
    </main>
  );
}
