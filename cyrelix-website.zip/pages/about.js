export default function About() {
  return (
    <main style={{ padding: "50px" }}>
      <h1>About Cyrelix</h1>
      <p>Cyrelix is a modern AI-driven vulnerability management solution by Infapro Solutions.</p>
    </main>
  );
}
